﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace TessierLab5
{
    class PersonV2: Person
    {
        private string cellPhone;
        private string instagramURL;

        public string CellPhone
        {
            get
            {
                return cellPhone;
            }

            set
            {
                cellPhone = value;
            }
        }

        public string InstagramURL
        {
            get
            {
                return instagramURL;
            }

            set
            {
                instagramURL = value;
            }
        }

        //This portion below adds a record, but only after making sure that the connection to the database is secured
        public string AddARecord()
        {
            //Initializing the string strResult variable
            string strResult = "";

            //Creates a connection object for the SQL server
            SqlConnection Conn = new SqlConnection();

            //This initializies the properties for the connection, through naming the server, server port, the database name, its user, and password
            Conn.ConnectionString = @"Server=sql.neit.edu,4500;Database=SE245_ATessier;User Id=SE245_atessier;Password=005501741;";

            string strSQL = "INSERT INTO PersonV2 (FirstName, MiddleName, LastName, Street1, Street2, City, State, Zipcode, Phone, Email, Instagram) VALUES (@FirstName, @MiddleName, @LastName, @Street1, @Street2, @City, @State, @Zipcode, @Phone, @Email, @Instagram)";

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = Conn;

            comm.Parameters.AddWithValue("@FirstName", FirstName);
            comm.Parameters.AddWithValue("@MiddleName", MiddleName);
            comm.Parameters.AddWithValue("@LastName", LastName);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2); 
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@Zipcode", ZipCode);
            comm.Parameters.AddWithValue("@Phone", Phone);
            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("@Instagram", InstagramURL);
            try
            {
                Conn.Open();
                int intRecs = comm.ExecuteNonQuery();
                strResult = $"Success: Connected to Aaron's Database and added {intRecs} for records.";
                Conn.Close();
            }
            catch (Exception err)
            {
                strResult = "ERROR: " + err.Message;
            }
            finally
            {

            }

            //StrResult is returned back to the main program
            return strResult;
        
        }

        public DataSet SearchARecord(String strFirstName, String strMiddleName, String strLastName, String strStreet1, String strStreet2, String strCity, String strState, String strZipcode, String strPhone, String strEmail, String strInstagram)
        {
            //Dataset initialization
            DataSet ds = new DataSet();

            //Connection initialization
            SqlCommand comm = new SqlCommand();

            //Initializing the SQL search string
            string strSql = "SELECT Person_ID, FirstName, MiddleName, LastName, Street1, Street2, City, State, Zipcode, Phone, Email, Instagram FROM PersonV2 WHERE 0=0";

            //Searching through for person's first name and last name
            if(strFirstName.Length > 0)
            {
                strSql += "AND FirstName LIKE @FirstName";
                comm.Parameters.AddWithValue("FirstName", "%" + strFirstName + "%");
            }

            if (strLastName.Length > 0)
            {
                strSql += "AND LastName LIKE @LastName";
                comm.Parameters.AddWithValue("LastName", "%" + strLastName + "%");
            }

            //Creating a connection for the SQL database
            SqlConnection conn = new SqlConnection();
            string strConn = @GetConnected();
            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = strSql;

            //Data adapter creation
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            //Filling in the dataset with data from the database
            conn.Open();
            //FILL IN DATASET AFTER MAKING THE SEARCH FORM GRID
            da.Fill(ds, "PERSON_Temp");
            conn.Close();

            return ds;
        }

        //Used as a "Key" to plug into SqlConnection, than writing out an entire string
        private string GetConnected()
        {
            return @"Server=sql.neit.edu,4500;Database=SE245_ATessier;User ID=SE245_ATessier;Password=005501741;";
        }

        public PersonV2(): base()
        {
            instagramURL = "";
            cellPhone = "";
        }
    }
}

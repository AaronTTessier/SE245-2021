﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TessierLab5
{
    class ValidatorLibrary
    {
        public static bool FilledInCorrectly(string temp, int len)
        {
            bool result = false;

            if (temp.Length == len)
            {
                result = true;
            }

            return result;
        }

        public static bool MinFilledInCorrectly(string temp, int minlen)
        {
            bool result = false;

            if (temp.Length >= minlen)
            {
                result = true;
            }

            return result;
        }

        public static bool MinDoubleFilledCorrectly(double temp, double min)
        {
            bool result = false;

            if (temp >= min)
            {
                result = true;
            }
            else
            {
                result = false;
            }

            return result;
        }

        public static bool MinIntFilledCorrectly(int temp, int min)
        {
            bool result = false;

            if (temp >= min)
            {
                result = true;
            }
            else
            {
                result = false;
            }

            return result;
        }

        public static bool IsValidPhoneChars(string temp)
        {
            bool result = true;

            string strValidPhoneChars = "0123456789-";
            foreach (char ch in temp)
            {
                if (strValidPhoneChars.Contains(ch) == false)
                {
                    result = false;
                }
            }

            return result;
        }

        public static bool IsValidState(string temp)
        {
            bool result = true;

            string[] stateArr = { "AL", "AK", "AS", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FM", "FL", "GA", "GU", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MH", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "MP", "OH", "OK", "OR", "PW", "PA", "PR", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VI", "VA", "WA", "WV", "WI", "WY" };

            foreach (string str in stateArr)
            {
                if (stateArr.Contains(temp.ToUpper()) == false)
                {
                    result = false;
                }
            }

            return result;
        }

        public static bool StateFilledInCorrectly(string temp)
        {
            return FilledInCorrectly(temp, 2);
        }

        public static bool CityFilledInCorrectly(string temp)
        {
            return MinFilledInCorrectly(temp, 4);
        }

        public static bool ZipFilledInCorrectly(string temp)
        {
            return FilledInCorrectly(temp, 5);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TessierLab5;

namespace Tessier_Lab7
{
    public partial class PersonSearch : Form
    {
        public PersonSearch()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void PersonSearch_Load(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2();

            DataSet ds = temp.SearchARecord(txtFName.Text, txtMName.Text, txtLName.Text, txtStreet1.Text, txtStreet2.Text, txtCity.Text, txtState.Text, txtZipCode.Text, txtPhoneNum.Text, txtEmail.Text, txtInstagramURL.Text);

            dgvPerson.DataSource = ds;
            dgvPerson.DataMember = ds.Tables["PERSON_Temp"].ToString();
        }
    }
}

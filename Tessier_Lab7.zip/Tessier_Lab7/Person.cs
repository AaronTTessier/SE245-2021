﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TessierLab5;

namespace TessierLab5
{
    public class Person
    {
        private string firstName;
        private string lastName;
        private string middleName;
        private string street1;
        private string street2;
        private string city;
        private string state;
        private string zipCode;
        private string phone;
        private string email;
        private string feedback;

        public string FirstName
        {
            get
            {
                return firstName;
            }

            set
            {
                firstName = value;
            }
        }

        public string MiddleName
        {
            get
            {
                return middleName;
            }

            set
            {
                middleName = value;
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }

            set
            {
                lastName = value;
            }
        }

        public string Street1
        {
            get
            {
                return street1;
            }

            set
            {
                street1 = value;
            }
        }

        public string Street2
        {
            get
            {
                return street2;
            }

            set
            {
                street2 = value;
            }
        }
        public string City
        {
            get
            {
                return city;
            }

            set
            {
                city = value;
            }
        }

        public string State
        {
            get
            {
                return state;
            }

            set
            {
                //Makes sure the state textbox was filled in with a correct format (ex., "RI", "CA", "MI")
                if(ValidatorLibrary.IsValidState(value))
                {
                    state = value;
                }
                else
                {
                    feedback += "\nWARNING: State is not filled in correctly.  Please enter state as 2-letter format.";
                }
            }
        }

        public string ZipCode
        {
            get
            {
                return zipCode;
            }

            set
            {
                zipCode = value;
            }
        }

        public string Phone
        {
            get
            {
                return phone;
            }

            set
            {
                phone = value;
            }
        }

        public string Email
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }

        public string Feedback
        {
            get
            {
                return feedback;
            }
        }

        public Person()
        {
            firstName = "";
            middleName = "";
            lastName = "";
            phone = "";
            email = "";
            feedback = "";

        }
    }
}
